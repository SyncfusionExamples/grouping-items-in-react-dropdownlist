import React from 'react';
import {DropDownListComponent} from '@syncfusion/ej2-react-dropdowns';
import {employees, socialMedia} from './data';
import './App.css';

function App() {
  const divStyle = {
    margin: 100,
    width: 250
  }

  const groupingTemplate=(props:any)=>{
    return(
      <div className='customGroup'>
        {props.Designation}
      </div>
    );
  }
  
  return (
    <div style={divStyle}>
      <DropDownListComponent dataSource={employees} placeholder="Select a name"
      groupTemplate={groupingTemplate}
      fields={{text:"Name", value:"EmployeeID", groupBy:"Designation"}}></DropDownListComponent>

      <DropDownListComponent id="icons" dataSource={socialMedia} placeholder="Select a social media"
      fields={{text: 'SocialMedia', value: 'Id', iconCss: 'Class'}}></DropDownListComponent>
    </div>
  );
}

export default App;
